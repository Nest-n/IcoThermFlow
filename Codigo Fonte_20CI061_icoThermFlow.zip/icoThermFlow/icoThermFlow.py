import numpy as np
import modin.pandas as mdp
import scipy.sparse as ssp
import time,os,logging
import cantera as ct
import multiprocessing as mtp
from queue import Queue
import pandas as pd

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s - %(message)s')
ch = logging.StreamHandler()
ch.setLevel(logging.DEBUG)
ch.setFormatter(formatter)
logger.addHandler(ch)

class SETUP:  
    def __init__(self,*args): 
        '''==============        SETUP       ================''' 
        self.pathHost = './'                                  #|
        self.nIteration = 500000                               #|
        self.nWorkers = 5                                    #|
        self.t_initial = 0
        self.nsave = 5
        '---------'                                           #|
        #Condition Chamber                                    #| 
        self.pAmb = 101325                          #[Pa]     #|
        self.TAmb = 27+273.15                       #[K]      #|
        self.Re = 400
        self.Thot = 150+273.15
        self.Tcold = 27+273.15
        '---------'                                           #|
        self.Mixture = {'O2':1,'N2':3.76}                              #|
        '---------'                                           #|
        #Constants                                            #|
        self.gravity = np.array((0.0,0,0))[:,None] #[m/s^2] #|
        self.nNodes = 8
class posProcessing():
    def __init__(self,time,v,d,p,T):
        self.phi = [d,p,T]
        self.v0 = v
        self.t = time
        self.nNodes = 8
        self.strPhi = ['rho','p','T']
        self.strVec = 'U'
        self.dimensionScalar = [
                    [1,-3,0,0,0,0,0],  #-> Density
                    [1,-1,-2,0,0,0,0], #-> Pressure
                    [0,0,0,1,0,0,0],   #-> Temperature
                        ]
        self.dimensionVec = [0,1,-1,0,0,0,0]        #Velocity

        self.endNoteScalar = '''
boundaryField
{
inlet
{
type            zeroGradient;
}
outlet
{
    type            zeroGradient;
}
WallLower
{
    type            zeroGradient;
}
WallUpper
{
    type            zeroGradient;
}
WallLeft
{
    type            zeroGradient;
}
WallRight
{
    type            zeroGradient;
}
}'''

        self.endNoteVector = '''
boundaryField
{
inlet
{
    type            empty;
}
outlet
{
    type            noSlip;
}
WallLower
{
    type            noSlip;
}
WallUpper
{
    type            noSlip;
}
WallLeft
{
    type            noSlip;
}
WallRight
{
    type            noSlip;
}
}'''
    def writerScalar(self,gdz,pos_gdz):
        path = self.pathHost + '%g/%s'%(self.t,
                            self.strPhi[pos_gdz])
        arq = open(path,'w+')
        with arq as p:
            p.write(
            '''/*--------------------------------*- C++ -*----------------------------------*\ \n
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Version:  6
     \\/     M anipulation  |
\*---------------------------------------------------------------------------*/
FoamFile
{
    version     2.0;
    format      ascii;
    class       volScalarField;
    location    "%g";
    object      %s;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //\n'''%(
            self.t,self.strPhi[pos_gdz])
            )
            p.write('dimensions\t[')
            for item in self.dimensionScalar[pos_gdz]:
                p.write('%d '%item)
            p.write('];\n')
            p.write('internalField   nonuniform List<scalar>\n')
            p.write('%d\n'%(len(self.ele)))
            p.write('(\n')
            for el in self.ele:
                nodes = self.nodesCell[el]
                self.Hex8Mesh(nodes,self.lNCtr)
                p.write('%.12f\n'%(self.N[None]@gdz[nodes]))
            p.write(')\n')
            p.write(';\n')
            p.write('%s'%self.endNoteScalar)

    def writerVector(self,gdz):
        path = self.pathHost + '%g/%s'%(self.t,self.strVec)
        arq = open(path,'w+')
        with arq as p:
            p.write(
     '''/*--------------------------------*- C++ -*----------------------------------*\ \n
   =========                 |
   \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
    \\    /   O peration     | Website:  https://openfoam.org
     \\  /    A nd           | Version:  6
      \\/     M anipulation  |
\*---------------------------------------------------------------------------*/
 FoamFile
 {
     version     2.0;
     format      ascii;
     class       volVectorField;
     location    "%g";
     object      %s;
 }
 // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * // \n'''%(
             self.t,self.strVec)
             )
            p.write('dimensions\t[')
            for item in self.dimensionVec:
                p.write('%d '%item)
            p.write('];\n')
            p.write('internalField   nonuniform List<vector>\n')
            p.write('%d\n'%(len(self.ele)))
            p.write('(\n')
            for el in self.ele:
                nodes = self.nodesCell[el]
                self.Hex8Mesh(nodes,self.lNCtr)
                value = gdz[nodes]
                p.write('(')
                for DoF in range(3):
                    if DoF<2:
                        p.write('%.12f '%(self.N[None]@value[:,DoF]))
                    else:
                        p.write('%.12f'%(self.N[None]@value[:,DoF]))
                p.write(')\n')
            p.write(')\n')
            p.write(';\n')
            p.write('%s'%self.endNoteVector)

    def timeWriter(self):
        try: 
            os.mkdir(self.pathHost + '%d'%self.t)
            cons_rho = mtp.Process(target = self.writerScalar, args = (
                self.phi[0],0))
            cons_p = mtp.Process(target = self.writerScalar, args = (
                self.phi[1],1))
            cons_T = mtp.Process(target = self.writerScalar, args = (
                self.phi[2],2))
            cons_U = mtp.Process(target = self.writerVector, args = (
                self.v0,))
            cons_rho.start(),cons_p.start()
            cons_T.start(),cons_U.start()
            cons_rho.join(),cons_p.join()
            cons_T.join(),cons_U.join()

        except:
            cons_rho = mtp.Process(target = self.writerScalar, args = (
                self.phi[0],0))
            cons_p = mtp.Process(target = self.writerScalar, args = (
                self.phi[1],1))
            cons_T = mtp.Process(target = self.writerScalar, args = (
                self.phi[2],2))
            cons_U = mtp.Process(target = self.writerVector, args = (
                self.v0,))
            cons_rho.start(),cons_p.start()
            cons_T.start(),cons_U.start()
            cons_rho.join(),cons_p.join()
            cons_T.join(),cons_U.join()
class meshReader(SETUP):
    def __init__(self):
        '''========         SETUP PRE-PROCESSING       =========='''
        SETUP.__init__(self)
        kwargs01 = dict(skiprows = 0,header = None,sep = '\s+',     #|
                skipfooter = 0, low_memory = False)                 #|
        kwargs02 = dict(skiprows = 19,sep = '\s+',
                skipfooter = 1,low_memory = False)                             #|
                                                                    #|
        self.paths = [self.pathHost + 'log.Assembly',               #|
                      self.pathHost + 'points',
                      self.pathHost + 'RegionAnalysis']             #|
                                                                    #|
        self.kwargs = [kwargs01, kwargs02,kwargs02]                          #|  
        #Patch Boundaty definite in BlockMesh                       #|
        self.patchBoundary = np.array((                             #|
                    'inlet','outlet','WallLower',                   #|
                    'WallUpper','WallLeft','WallRight'              #|
                                    ))                              #|
    def readAchive(self,args):
        path,kwarg = args
        'read BlockMesh archives for the DataFrame'
        return mdp.read_csv(path,**kwarg)

    def reader(cls):
        #Reading in process parallel
        df = []
        for i in range(len(cls.paths)):
            df.append(cls.readAchive((cls.paths[i],
                                      cls.kwargs[i]))) 
        #Converting DataFrame to numpy.array
        df0 = np.asarray(df[0],np.int)
        df1 = np.asarray(df[1],np.float)
        df2 = np.unique(np.asarray(df[2],np.int))
        cls.ele,cls.nodesCell = np.arange(0,len(df0)),df0
        cls.coordPoints = df1 
        cls.eleInternal = df2
        
        cls.eleB,cls.nodesB = [],[]
        for name in cls.patchBoundary:
            cls.eleB.append(cls.readAchive((cls.pathHost + 
                    '/constant/ElementsBoundary/ele_%s'%name, cls.kwargs[0])))
            cls.nodesB.append(cls.readAchive((cls.pathHost +
                    '/constant/NodesBoundary/nodes_%s'%name, cls.kwargs[0])))
        
        cls.map_Inlet     = (np.asarray(cls.eleB[0],np.int)[:,0],
                             np.asarray(cls.nodesB[0],np.int)[:,0])
        cls.map_Outlet    = (np.asarray(cls.eleB[1],np.int)[:,0],
                             np.asarray(cls.nodesB[1],np.int)[:,0])
        cls.map_WallLower = (np.asarray(cls.eleB[2],np.int)[:,0],
                             np.asarray(cls.nodesB[2],np.int)[:,0])
        cls.map_WallUpper = (np.asarray(cls.eleB[3],np.int)[:,0],
                             np.asarray(cls.nodesB[3],np.int)[:,0])
        cls.map_WallLeft  = (np.asarray(cls.eleB[4],np.int)[:,0],
                             np.asarray(cls.nodesB[4],np.int)[:,0])
        cls.map_WallRight = (np.asarray(cls.eleB[5],np.int)[:,0],
                            np.asarray(cls.nodesB[5],np.int)[:,0])
        cls.mapInternal = (cls.eleInternal,np.unique(cls.nodesCell[cls.eleInternal]))

    def isoHex8(self):
        '''
            This function aims to return the gauss points
        to an 8-node Hexahedral Isoparametric mesh.

        Local coordenates of nodes in elements ---> (ξ,η,ζ)

        IOANNIS et al. Fundamentals of Finite Element Analysis. 2018.
                        pag 274.

                             7------------6
                            /|           /|
                           / |          / |
                          /  |         /  |
                         /   |        /   |
                        4----|-------5    |
                        |    3-------|----2
          ζ             |   /        |   /
          ^ η           |  /         |  /
          | /           | /          | /
          |/            |/           |/
          |------>ξ     0------------1
        '''
        self.lN = np.array((
             (-1,-1,-1),
             (1,-1,-1),
             (1,1,-1),
             (-1,1,-1),
             (-1,-1,1),
             (1,-1,1),
             (1,1,1),
             (-1,1,1)
             ))
        self.lNCtr = np.array((0,0,0)) #Centroid of element
        self.gaussP = np.array((
                    (-1/3**0.5,-1/3**0.5,-1/3**0.5),
                    (1/3**0.5,-1/3**0.5,-1/3**0.5),
                    (1/3**0.5,1/3**0.5,-1/3**0.5),
                    (-1/3**0.5,1/3**0.5,-1/3**0.5),
                    (-1/3**0.5,-1/3**0.5,1/3**0.5),
                    (1/3**0.5,-1/3**0.5,1/3**0.5),
                    (1/3**0.5,1/3**0.5,1/3**0.5),
                    (-1/3**0.5,1/3**0.5,1/3**0.5)
                        ))
        self.wGauss = np.array((1.,1.,1.,1.,1.,1.,1.,1.))

    def isoHex8_Boundary(self):
        #Gauss Points in Boundary
        '''The boundary points have been positioned so that the
         Normal vector always with outward direction! '''
        self.gP2D_Inlet = np.array((
                    (-1/3**0.5,-1,-1/3**0.5),
                    (1/3**0.5,-1,-1/3**0.5),
                    (1/3**0.5,-1,1/3**0.5),
                    (-1/3**0.5,-1,1/3**0.5)
                                    ))
        self.gP2D_Outlet = np.array((
                    (-1/3**0.5,1,-1/3**0.5),
                    (-1/3**0.5,1,1/3**0.5),
                    (1/3**0.5,1,1/3**0.5),
                    (1/3**0.5,1,-1/3**0.5)
                                    ))
        self.gP2D_WallRight = np.array((
                    (1,-1/3**0.5,-1/3**0.5),
                    (1,1/3**0.5,-1/3**0.5),
                    (1,1/3**0.5,1/3**0.5),
                    (1,-1/3**0.5,1/3**0.5)
                                       ))
        self.gP2D_WallLeft = np.array((
                    (-1,-1/3**0.5,-1/3**0.5),
                    (-1,-1/3**0.5,1/3**0.5),
                    (-1,1/3**0.5,1/3**0.5),
                    (-1,1/3**0.5,-1/3**0.5)
                                    ))
        self.gP2D_WallUpper = np.array((
                    (-1/3**0.5,-1/3**0.5,1),
                    (1/3**0.5,-1/3**0.5,1),
                    (1/3**0.5,1/3**0.5,1),
                    (-1/3**0.5,1/3**0.5,1)
                                        ))
        self.gP2D_WallLower = np.array((
                    (-1/3**0.5,-1/3**0.5,-1),
                    (-1/3**0.5,1/3**0.5,-1),
                    (1/3**0.5,1/3**0.5,-1),
                    (1/3**0.5,-1/3**0.5,-1)
                                        ))

        self.wGauss2D = np.array((1.,1.,1.,1.))

    def Hex8Mesh(self,nodes,gP):
        '''
            Application of interpolation functions. These
        take into account only the mesh element geometry,
        as my mesh is initially composed of HEXAHEDRONS
        ISOPARAMETRIC elements,

        IOANNIS et al. Fundamentals of Finite Element Analysis. 2018.
        pag 266.
        '''
        csi,eta,zeta = gP.T
        #Interpolation Functions
        self.N = 1/8*np.array((
            (1-csi)*(1-eta)*(1-zeta),(1+csi)*(1-eta)*(1-zeta),
            (1+csi)*(1+eta)*(1-zeta),(1-csi)*(1+eta)*(1-zeta),
            (1-csi)*(1-eta)*(1+zeta),(1+csi)*(1-eta)*(1+zeta),
            (1+csi)*(1+eta)*(1+zeta),(1-csi)*(1+eta)*(1+zeta)
                        ))
        #Derivatives of Interpolation Funstions
        'IOANNIS (2018) pag 269'
        self.dNdcsi = 1/8*np.array((
            (-(1-eta)*(1-zeta), (1-eta)*(1-zeta),
              (1+eta)*(1-zeta),-(1+eta)*(1-zeta),
             -(1-eta)*(1+zeta), (1-eta)*(1+zeta),
              (1+eta)*(1+zeta),-(1+eta)*(1+zeta)),
            (-(1-csi)*(1-zeta),-(1+csi)*(1-zeta),
              (1+csi)*(1-zeta), (1-csi)*(1-zeta),
             -(1-csi)*(1+zeta),-(1+csi)*(1+zeta),
              (1+csi)*(1+zeta), (1-csi)*(1+zeta)),
            (-(1-csi)*(1-eta),-(1+csi)*(1-eta),
             -(1+csi)*(1+eta),-(1-csi)*(1+eta),
              (1-csi)*(1-eta), (1+csi)*(1-eta),
              (1+csi)*(1+eta), (1-csi)*(1+eta))
                                  ))
        J = (self.coordPoints[nodes].T@self.dNdcsi.T).T #Jacobian
        self.detJ = np.linalg.det(J)  #Det of Jacobian
        self.invJ = np.linalg.inv(J)
        #if boundary is True:
        '''
        Face area with constant CSI coordinate
                WallLEFT and WallRIGHT          '''
        self.detJ_2Dcsi = np.sqrt(
            (J[1,0]*J[2,1] - J[1,1]*J[2,0])**2 +
            (J[1,2]*J[2,0] - J[1,0]*J[2,2])**2 +
            (J[1,1]*J[2,2] - J[1,2]*J[2,1])**2
                                )
        '''
        Face area with constant ETA coordinate
                    INLET and OUTLET          '''
        self.detJ_2Deta = np.sqrt(
            (J[2,0]*J[0,1] - J[2,1]*J[0,0])**2 +
            (J[2,2]*J[0,0] - J[2,0]*J[0,2])**2 +
            (J[2,1]*J[0,2] - J[2,2]*J[0,1])**2
                                )
        '''
        Face area with constant ETA coordinate
                WallLOWER and WallUPPER          '''
        self.detJ_2Dzeta = np.sqrt(
            (J[0,0]*J[1,1] - J[0,1]*J[1,0])**2 +
            (J[0,2]*J[1,0] - J[0,0]*J[1,2])**2 +
            (J[0,1]*J[1,2] - J[0,2]*J[1,1])**2
                                )
class checkMesh(meshReader):
    def __init__(self):
        meshReader.__init__(self)
        meshReader.reader(self)
        self.queue_in = mtp.JoinableQueue()
        self.posições = mtp.Queue()
    def verify(self,EleT):
        minLen,maxLen = 1,0
        for e in EleT:
            nodes = self.nodesCell[e]
            caracLen = np.max(np.sqrt(np.sum(
                            (self.coordPoints[nodes[0]] -
                             self.coordPoints[nodes[1:]])**2,axis=1)))
            if minLen > caracLen:
                minLen = caracLen
            if maxLen < caracLen:
                maxLen = caracLen
        return minLen,maxLen

    def producer(self,EleT,queue_in):
        try:
            split_Ele = np.hsplit(EleT,self.nWorkers)
            for s in split_Ele:
                queue_in.put(s)
        except:
            split_Ele = np.hsplit(EleT,10)
            for s in split_Ele:
                queue_in.put(s)
    def consumer(self,queue_in,queue_pos):
        while True:
            EleT = queue_in.get()
            minLen,maxLen = self.verify(EleT)
            queue_pos.put((minLen,maxLen))
            queue_in.task_done()
    def ParallelCheckMesh(self):
        consumer_list = []
        for i in range(self.nWorkers):
            cons = mtp.Process(target = self.consumer,
                        args = (self.queue_in,self.posições))
            consumer_list.append(cons)
        [cons.start() for cons in consumer_list]
        prod = mtp.Process(target = self.producer,
                        args = (self.ele,self.queue_in))
        prod.start()
        prod.join()
        self.queue_in.join()
        minLen,maxLen = [],[]
        while not self.posições.empty():
            auxMin,auxMax = self.posições.get()
            minLen.append(auxMin)
            maxLen.append(auxMax)
        [cons.terminate() for cons in consumer_list]
        time.sleep(0.1)
        [cons.close() for cons in consumer_list]
        prod.close()
        self.minLen,self.maxLen = min(minLen),max(maxLen)

class CBS(checkMesh,posProcessing):
    def __init__(self):
        checkMesh.__init__(self)
        checkMesh.ParallelCheckMesh(self)
        self.isoHex8()
        self.gasMix = ct.Solution('gri30.xml')
        self.gasMix.X = self.Mixture

    def viscosity(self,T):
        '''Sutherland's law --> SI'''
        return 1.45*T**(3/2)/(T + 110)*1.0E-6

    def thermalConductivity(self,T):
        '''pag 724 
        modified Eucken correlation
        '''
        return self.viscosity(T)*(1.32*self.gasMix.cv + 
                1.4728E4/self.gasMix.mean_molecular_weight)
        
    def initCondition(self):
        if self.t_initial == 0:
            self.v0 = np.zeros_like(self.coordPoints)
            self.T0 = np.zeros(len(self.coordPoints))[:,None]
            self.p0 = np.zeros(len(self.coordPoints))[:,None]
            self.d0 = np.zeros(len(self.coordPoints))[:,None]

            #State of injector
            self.gasMix.TP = self.TAmb,self.pAmb
            vIn = self.Re*self.viscosity(self.TAmb)/self.gasMix.density#6.2775E-3
            self.vIn = vIn
            #Initial Condition Chamber
            self.T0[:],self.p0[:] = self.TAmb,self.pAmb
            self.d0[:] = self.gasMix.density
            
            Pr = self.gasMix.cp*self.viscosity(self.TAmb)/self.thermalConductivity(self.TAmb)
            print('Densidade : ',self.gasMix.density)
            print('Viscosidade: ',self.viscosity(self.TAmb))
            print('Cond. Térmica: ',self.thermalConductivity(self.TAmb))
            print('Velocidade Inicial: ',vIn)
            print('Reynolds: ', self.Re)
            print('Pr: ', Pr)

            self.v0[self.map_Inlet[1],0] = vIn
            self.v0[self.map_WallLeft[1],:] = 0 
            self.v0[self.map_WallRight[1],:] = 0 
            self.v0[self.map_WallLower[1],:] = 0 
            self.v0[self.map_WallUpper[1],:] = 0
            self.v0[self.map_Outlet[1],:] = 0
            
            self.T0[self.map_WallLeft[1]] = self.Thot
            self.T0[self.map_WallRight[1]] = self.Tcold
        else:
            kwargs = dict(header=None,sep = '\s+',low_memory = False)

            def readAchive(args):
                path,kwarg = args
                'read BlockMesh archives for the DataFrame'
                return mdp.read_csv(path,**kwarg)
            
            path = './%s/'%(int(self.t_initial/self.nsave))
            names = ['U_backup','p_backup','rho_backup','T_backup']
            
            self.v0 = np.asarray(readAchive((path+names[0],kwargs)))
            self.p0 = np.asarray(readAchive((path+names[1],kwargs)))
            self.d0 = np.asarray(readAchive((path+names[2],kwargs)))
            self.T0 = np.asarray(readAchive((path+names[3],kwargs)))

    def SourceMomentum(self,e,nodes,v,T):
        f = np.zeros((3,self.nNodes))
        self.isoHex8_Boundary()
        def source(Nboundary,nodesGauss,nodes,det,f,v,pos):
            vec1 = self.lN[pos[0]] - self.lN[pos[2]]
            vec2 = self.lN[pos[1]] - self.lN[pos[3]]
            n = np.cross(vec1,vec2)
            n = n/np.sqrt(np.sum(n**2))
            pos = np.sort(pos)
            I0 = np.diag((0,0,0,1,1,1))
            m = np.array((1,1,1,0,0,0))[None].T
            mmT = m@m.T
            for g,pt2d in enumerate(nodesGauss):
                self.Hex8Mesh(nodes,pt2d)
                dNudx = self.invJ@self.dNdcsi
                B = np.vstack((dNudx,dNudx[0] + dNudx[1],
                    dNudx[1] + dNudx[2],dNudx[0] + dNudx[2]))
                for i in range(3):
                    sigma = self.viscosity(T)*I0@B@v[:,i]  #Tensor full
                    sigma = np.array((
                                    (sigma[0],sigma[3],sigma[5]),
                                    (sigma[3],sigma[1],sigma[4]),
                                    (sigma[5],sigma[4],sigma[2])
                                    ))
                    t = np.diag(sigma)*n
                    f[i,pos] = f[i,pos] + self.N[pos]*t[i]*det*self.wGauss2D[g]
            return f
        if e in self.map_Inlet[0]:
            f = source(self.map_Inlet[1],self.gP2D_Inlet,
                       nodes,self.detJ_2Deta,f,v,[0,1,5,4])
        if e in self.map_WallLeft[0]:
            f = source(self.map_WallLeft[1],self.gP2D_WallLeft,
                       nodes,self.detJ_2Dcsi,f,v,[0,4,7,3])
        if e in self.map_WallRight[0]:
            f = source(self.map_WallRight[1],self.gP2D_WallRight,
                       nodes,self.detJ_2Dcsi,f,v,[1,2,6,5])
        if e in self.map_WallUpper[0]:
            f = source(self.map_WallUpper[1],self.gP2D_WallUpper,
                       nodes,self.detJ_2Dzeta,f,v,[4,5,6,7])
        if e in self.map_WallLower[0]:
            f = source(self.map_WallLower[1],self.gP2D_WallLower,
                       nodes,self.detJ_2Dzeta,f,v,[0,3,2,1])
        if e in self.map_Outlet[0]:
            f = source(self.map_Outlet[1],self.gP2D_Outlet,
                       nodes,self.detJ_2Deta,f,v,[2,3,7,6])
        return f

    def SourceContinuity(self,e,nodes,v,d,Du):
        f = np.zeros((3,self.nNodes))
        self.isoHex8_Boundary()
        def source(Nboundary,nodesGauss,nodes,det,f,v,Du,pos):
            vec1 = self.lN[pos[0]] - self.lN[pos[2]]
            vec2 = self.lN[pos[1]] - self.lN[pos[3]]
            n = np.cross(vec1,vec2)
            n = n/np.sqrt(np.sum(n**2))
            U = d*v
            pos = np.sort(pos)
            for g,pt2d in enumerate(nodesGauss):
                self.Hex8Mesh(nodes,pt2d)
                N,dNdx = self.N,self.invJ@self.dNdcsi
                for i in range(3):
                    f[i,pos] = f[i,pos] + self.N[pos]*(U[pos,i] + 
                            self.theta1*Du[pos,i])*n[i]*det*self.wGauss2D[g]
            return f
        if e in self.map_Inlet[0]:
            f = source(self.map_Inlet[1],self.gP2D_Inlet,
                       nodes,self.detJ_2Deta,f,v,Du,[0,1,5,4])
        if e in self.map_WallLeft[0]:
            f = source(self.map_WallLeft[1],self.gP2D_WallLeft,
                       nodes,self.detJ_2Dcsi,f,v,Du,[0,4,7,3])
        if e in self.map_WallRight[0]:
            f = source(self.map_WallRight[1],self.gP2D_WallRight,
                       nodes,self.detJ_2Dcsi,f,v,Du,[1,2,6,5])
        if e in self.map_WallUpper[0]:
            f = source(self.map_WallUpper[1],self.gP2D_WallUpper,
                       nodes,self.detJ_2Dzeta,f,v,Du,[4,5,6,7])
        if e in self.map_WallLower[0]:
            f = source(self.map_WallLower[1],self.gP2D_WallLower,
                       nodes,self.detJ_2Dzeta,f,v,Du,[0,3,2,1])
        if e in self.map_Outlet[0]:
            f = source(self.map_Outlet[1],self.gP2D_Outlet,
                       nodes,self.detJ_2Deta,f,v,Du,[2,3,7,6])
        return np.sum(f,axis = 0)
 
    def SourceEnergy(self,e,nodes,v,T):
        f = np.zeros((3,self.nNodes))
        self.isoHex8_Boundary()
        def source(Nboundary,nodesGauss,nodes,det,f,v,pos):
            vec1 = self.lN[pos[0]] - self.lN[pos[2]]
            vec2 = self.lN[pos[1]] - self.lN[pos[3]]
            n = np.cross(vec1,vec2)
            n = n/np.sqrt(np.sum(n**2))
            pos = np.sort(pos)
            I0 = np.diag((0,0,0,1,1,1))
            m = np.array((1,1,1,0,0,0))[None].T
            mmT = m@m.T
            for g,pt2d in enumerate(nodesGauss):
                self.Hex8Mesh(nodes,pt2d)
                dNudx = self.invJ@self.dNdcsi
                B = np.vstack((dNudx,dNudx[0] + dNudx[1],
                    dNudx[1] + dNudx[2],dNudx[0] + dNudx[2]))
                for i in range(3):
                    sigma = self.viscosity(T)*I0@B@v[:,i]  #Tensor full
                    sigma = np.array((
                                    (sigma[0],sigma[3],sigma[5]),
                                    (sigma[3],sigma[1],sigma[4]),
                                    (sigma[5],sigma[4],sigma[2])
                                    ))
                    t = np.diag(sigma)*n
                    f[i,pos] = f[i,pos] + self.N[pos]*t[i]*det*self.wGauss2D[g]
            return f
        if e in self.map_Inlet[0]:
            f = source(self.map_Inlet[1],self.gP2D_Inlet,
                       nodes,self.detJ_2Deta,f,v,[0,1,5,4])
        if e in self.map_WallLeft[0]:
            f = source(self.map_WallLeft[1],self.gP2D_WallLeft,
                       nodes,self.detJ_2Dcsi,f,v,[0,4,7,3])
        if e in self.map_WallRight[0]:
            f = source(self.map_WallRight[1],self.gP2D_WallRight,
                       nodes,self.detJ_2Dcsi,f,v,[1,2,6,5])
        if e in self.map_WallUpper[0]:
            f = source(self.map_WallUpper[1],self.gP2D_WallUpper,
                       nodes,self.detJ_2Dzeta,f,v,[4,5,6,7])
        if e in self.map_WallLower[0]:
            f = source(self.map_WallLower[1],self.gP2D_WallLower,
                       nodes,self.detJ_2Dzeta,f,v,[0,3,2,1])
        if e in self.map_Outlet[0]:
            f = source(self.map_Outlet[1],self.gP2D_Outlet,
                       nodes,self.detJ_2Deta,f,v,[2,3,7,6])
        return np.sum(f,axis=0)
   
 
    def bcMomentum(self,e,nodes,M,F,D):
        def prescrit(Nboundary,nodes,M,F,D):
            pos = np.argwhere(np.isin(nodes,Nboundary))[:,0]
            F[pos],D[pos],M[pos],M[:,pos] = 0,0,0,0
            M[pos,pos] = 1
            return M,F,D
        if e in self.map_Inlet[0]:
            M,F,D = prescrit(self.map_Inlet[1],nodes,M,F,D)
        if e in self.map_WallLeft[0]:
            M,F,D = prescrit(self.map_WallLeft[1],nodes,M,F,D)
        if e in self.map_WallRight[0]:
            M,F,D = prescrit(self.map_WallRight[1],nodes,M,F,D)
        if e in self.map_WallUpper[0]:
            M,F,D = prescrit(self.map_WallUpper[1],nodes,M,F,D)
        if e in self.map_WallLower[0]:
            M,F,D = prescrit(self.map_WallLower[1],nodes,M,F,D)
        if e in self.map_Outlet[0]:
            M,F,D = prescrit(self.map_Outlet[1],nodes,M,F,D)
        return M,F,D

    def bcEnergy(self,e,nodes,M,F,D):
        def prescrit(Nboundary,nodes,M,F,D):
            pos = np.argwhere(np.isin(nodes,Nboundary))[:,0]
            F[pos],D[pos],M[pos],M[:,pos] = 0,0,0,0
            M[pos,pos] = 1
            return M,F,D
        
        if e in self.map_WallLeft[0]:
            M,F,D = prescrit(self.map_WallLeft[1],nodes,M,F,D)
        if e in self.map_WallRight[0]:
            M,F,D = prescrit(self.map_WallRight[1],nodes,M,F,D)
        return M,F,D

    def EbE(self,nodesRef,EleT,res,diag,M,D):
        res = res.reshape((len(res),))
        D = D.reshape((len(D),))
        diag = 1/diag
        resmean = res
        d = diag*res
        dmean = diag*resmean

        q = np.zeros_like(res)
        qmean = np.zeros_like(res)

        erro = np.sum(res*d)
        for i in range(5000):
            for el in EleT:
                nodes = np.argwhere(np.isin(nodesRef,self.nodesCell[el]))[:,0]
                q[nodes] = q[nodes] + (M[nodes][:,nodes])@d[nodes]
                qmean[nodes] = qmean[nodes] + (M[nodes][:,nodes]).T@dmean[nodes]
            alpha = np.sum(dmean*q) + 1.0E-20
            D = D + erro/alpha*d
            res = res - erro/alpha*q
            resmean = resmean - erro/alpha*qmean
            erro_mean = erro + 1.0E-20
            erro = np.sum(res*diag*resmean)

            alpha = erro/erro_mean
            d = diag*res + alpha*d
            dmean = diag*resmean + alpha*dmean

            q[:],qmean[:] = 0,0
            if abs(erro) < 1.0E-8:
                break
        if i == 4999:
            print('WARNNING: Not convergence in 5000 iterations')
        return D,erro
    
    def SplitB(self,EleT,v0,d0,p0,T0,vmax):
        '''                Linear System
                              MΔΦ = F
        M  -> Mass matrix
        ΔΦ -> Variable split
        F  -> Source term                                   '''
        Muglobal = ssp.lil_matrix(( len(v0),len(v0) ))
        Mpglobal = ssp.lil_matrix(( len(p0),len(p0) ))
        MEglobal = ssp.lil_matrix(( len(T0),len(T0) ))
        Fu,Fp,FE = np.zeros_like(v0),np.zeros_like(p0),np.zeros_like(T0)
        Du,Dp,DE = np.zeros_like(v0),np.zeros_like(p0),np.zeros_like(T0)
        Du2 = np.zeros_like(v0)
        ##---------         RESIDUOS               -----------##
        ru,rp,rE = np.zeros_like(v0),np.zeros_like(p0),np.zeros_like(T0)
        diagu,diagp,diagE = np.zeros(len(v0)),np.zeros(len(p0)),np.zeros(len(T0))
        ##---------         CONSTANTS              -----------##
        I0 = np.diag((0,0,0,1,1,1))
        self.theta1 = 1
        self.theta2 = 1
        ##--------          REFERENCES             -----------##
        nodesRef = np.unique(self.nodesCell[EleT])
        newRef = dict(zip(nodesRef,range(len(nodesRef))))
        for e in EleT:
            nodesAux = self.nodesCell[e]
            nodes = []
            for nd in nodesAux:
                nodes.append(newRef[nd])
            v,p,d,T = v0[nodes],p0[nodes],d0[nodes],T0[nodes]
            gamma = self.gasMix.cp/self.gasMix.cv
            E = 1/(gamma -1)*p + 0.5*d*np.sum(v**2,axis=1)
            
            Mu,Cu,Ku,Kt = 0,0,0,0
            G = np.zeros((3,self.nNodes,self.nNodes))
            P = np.zeros((3,self.nNodes,self.nNodes))
            fs = np.zeros((3,self.nNodes))
            f = np.zeros((3,self.nNodes))
            ME,KT,KtE,CE = 0,0,0,0
            KuE = np.zeros((3,self.nNodes,self.nNodes))
            for g,gP in enumerate(self.gaussP):
                self.Hex8Mesh(nodesAux,gP)
                N,invJ = self.N,self.invJ
                dNdx = self.invJ@self.dNdcsi
                #Global Values
                vCell,dCell,pCell,TCell = N@v,N@p,N@d,N@T
                vCell = vCell[None].T
                gamma = self.gasMix.cp/self.gasMix.cv
                R = self.gasMix.cp - self.gasMix.cv
                spSound = np.sqrt(gamma*R*TCell)
                #Divergent ∇(uNu)
                divTuNu = ((dNdx[0,None].T@v[:,0][None] + dNdx[1,None].T@v[:,1][None] + 
                           dNdx[2,None].T@v[:,2][None])@N[None].T + vCell[0]*dNdx[0,None].T +
                           vCell[1]*dNdx[1,None].T + vCell[2]*dNdx[2,None].T).T 
                divuNu = divTuNu
                #-------------------------------------------------#
                Mu = Mu + N[None].T@N[None]*self.detJ*self.wGauss[g]
                Cu = Cu + N[None].T@divuNu*self.detJ*self.wGauss[g]
                Ku = Ku + divTuNu.T@divTuNu*self.detJ*self.wGauss[g]
                B = np.vstack((dNdx, dNdx[0] + dNdx[1],
                    dNdx[1] + dNdx[2], dNdx[0] + dNdx[2]))
                Kt = Kt + self.viscosity(TCell)*B.T@I0@B*self.detJ*self.wGauss[g]
                #-------------------------------------------------#
                ME = Mu
                KT = KT + self.thermalConductivity(TCell)*dNdx.T@dNdx*self.detJ*self.wGauss[g]
                CE = CE + N[None].T@divTuNu*self.detJ*self.wGauss[g]
                KtE = Kt*np.mean(vCell)
                for i in range(3):
                    G[i] = G[i] + dNdx[i,None].T@N[None]*self.detJ*self.wGauss[g]
                    P[i] = P[i] + divuNu.T@dNdx[i,None]*self.detJ*self.wGauss[g]
                    f[i] = f[i] + dCell*N*self.gravity[i]*self.detJ*self.wGauss[g]
                    fs[i] = fs[i] + dCell*divTuNu*self.gravity[i]*self.detJ*self.wGauss[g]
                    #-------------------------------------------------#
                    KuE[i] = KuE[i] - 0.5*divTuNu.T@dNdx[i,None]*self.detJ*self.wGauss[g]
            fc = self.SourceMomentum(e,nodesAux,v,TCell)
            beta = 0.1
            Dt = self.minLen/vmax*0.5
            U = d*v
            for i in range(3):
                Fu[nodes,i] = -Dt*(Cu@U[:,i] + Kt@v[:,i] + G[i].T@p[:,0] - f[i] -
                        fc[i] + 0.5*Dt*(Ku@U[:,i] + P[i]@p[:,0] - fs[i]))
            fe = self.SourceEnergy(e,nodesAux,v,TCell)
            FE[nodes] = -Dt*(CE@E[:,0] + CE@p[:,0] + sum(KtE@v[:,i] for i in range(3)) +
                    KT@T[:,0] + fe - Dt*(sum(KuE[i]@E[:,0] + KuE[i]@p[:,0] for i in range(3))))[:,None]
            '''/--------------------------  BOUNDARY CONDITIONS ----------------------------\ '''
            Mu,Fu[nodes],Du[nodes] = self.bcMomentum(e,nodesAux,Mu,Fu[nodes],Du[nodes])
            ME,FE[nodes],DE[nodes] = self.bcEnergy(e,nodesAux,ME,FE[nodes],DE[nodes])
            '''\----------------------------------------------------------------------------/ '''
            for posl,l in enumerate(nodes):
                for posc,c in enumerate(nodes):
                    Muglobal[l,c] += Mu[posl,posc]
                    MEglobal[l,c] += ME[posl,posc]
            ru[nodes] = ru[nodes] + Fu[nodes] - Mu@Du[nodes]
            diagu[nodes] = diagu[nodes] +  np.diag(Mu)
            ##---------------------------------------------------------------------------##
            rE[nodes] = rE[nodes] + FE[nodes] - ME@DE[nodes]
            diagE[nodes] = diagE[nodes] + np.diag(ME)

        Du[:,0],erroUx = self.EbE(nodesRef,EleT,ru[:,0],diagu,Muglobal,Du[:,0])
        Du[:,1],erroUy = self.EbE(nodesRef,EleT,ru[:,1],diagu,Muglobal,Du[:,1])
        Du[:,2],erroUz = self.EbE(nodesRef,EleT,ru[:,2],diagu,Muglobal,Du[:,2])
        DE,erroE = self.EbE(nodesRef,EleT,rE,diagE,MEglobal,DE)
        for e in EleT:
            nodesAux = self.nodesCell[e]
            nodes = []
            for nd in nodesAux:
                nodes.append(newRef[nd])
            v,p,d,T = v0[nodes],p0[nodes],d0[nodes],T0[nodes]
            Mp,H = 0,0
            G = np.zeros((3,self.nNodes,self.nNodes))
            for g,gP in enumerate(self.gaussP):
                self.Hex8Mesh(nodesAux,gP)
                N,invJ = self.N,self.invJ
                dNdx = self.invJ@self.dNdcsi
                H = H + dNdx.T@dNdx*self.detJ*self.wGauss[g]
                Mp = Mp + (1/beta**2)*N[None].T@N[None]*self.detJ*self.wGauss[g]
                for i in range(3):
                    G[i] = G[i] + dNdx[i,None].T@N[None]*self.detJ*self.wGauss[g]

            U = d*v
            fp = self.SourceContinuity(e,nodesAux,v,d,Du[nodes])
            Fp[nodes] = Dt*(sum(G[i]@U[:,i] + self.theta1*G[i]@Du[nodes,i] for i in range(3)) - fp)[:,None]
            Mp = (Mp + Dt**2*self.theta1*self.theta2*H)
            for posl,l in enumerate(nodes):
                for posc,c in enumerate(nodes):
                    Mpglobal[l,c] += Mp[posl,posc]

            rp[nodes] = rp[nodes] + Fp[nodes] - Mp@Dp[nodes]
            diagp[nodes] = diagp[nodes] + np.diag(Mp)
        ##------##
        Dp,errop= self.EbE(nodesRef,EleT,rp,diagp,Mpglobal,Dp)
        Dp = Dp[:,None]
        ## Updated Time
        DT = (DE - 0.5*np.sum(Du**2,axis=1))/(d0[:,0]*self.gasMix.cv)
        ## Updated Time
        p0 = p0 + Dp
        T0 = T0 + DT[:,None]

        v0[:,0] = v0[:,0] + Du[:,0]/d0[:,0]
        v0[:,1] = v0[:,1] + Du[:,1]/d0[:,0]
        v0[:,2] = v0[:,2] + Du[:,2]/d0[:,0]
        result = pd.DataFrame([nodesRef,v0,d0,p0,T0]).T
        return result

    def pdProcess(self,EleT,queue_in):
        try:
            split_Ele = np.hsplit(EleT,self.nWorkers)
            for s in split_Ele:
                queue_in.put(s)
        except:
            split_Ele = np.hsplit(EleT,100)
            for s in split_Ele:
                queue_in.put(s)

    def consProcess(self,queue_in,queue_out):
        while True:
            EleT = queue_in.get()
            nodes = np.unique(self.nodesCell[EleT])
            v0,d0,p0,T0 = self.v0[nodes],self.d0[nodes],self.p0[nodes],self.T0[nodes]
            vmax = abs(np.max(np.sqrt(np.sum(self.v0**2,axis=1))))
            queue_out.put(self.SplitB(EleT,v0,d0,p0,T0,vmax))
            queue_in.task_done()

    def ParallelProcessing(self):
        logger.info('Initial Processing')
        self.initCondition()
        ##Printing Data
        print('\n================================================================\n')
        for t in range(self.t_initial,self.nIteration):
            logger.info('Iteration %d'%(t)) 
            if t%self.nsave == 0:

                posProcessing.__init__(self,int(t/self.nsave),self.v0,self.d0,self.p0,self.T0)
                self.timeWriter()
                
                reloadNodes = mdp.read_csv(self.pathHost + './log.Assembly',sep='\s+',header = None)
                self.nodesCell = np.asarray(reloadNodes,np.int) 

                np.savetxt('./%d/U_backup'%(t/self.nsave),self.v0,fmt='%.6e')
                np.savetxt('./%d/rho_backup'%(t/self.nsave),self.d0,fmt='%.2e')
                np.savetxt('./%d/p_backup'%(t/self.nsave),self.p0,fmt='%.6e')
                np.savetxt('./%d/T_backup'%(t/self.nsave),self.T0,fmt='%.2e')
   
            vSave = self.v0
            pSave = self.p0
            TSave = self.T0
            
            queue_in = mtp.JoinableQueue()
            queue_out= mtp.Queue()
            consumer_list = []
            for i in range(self.nWorkers):
                cons = mtp.Process(target = self.consProcess,
                        args = (queue_in,queue_out))
                consumer_list.append(cons)
            [cons.start() for cons in consumer_list]
            prod = mtp.Process(target = self.pdProcess, 
                        args = (self.ele,queue_in))
            prod.start()
            prod.join()
            queue_in.join()
            list_return = []
            while not queue_out.empty():
                list_return.append(queue_out.get())
            [cons.terminate() for cons in consumer_list]
            prod.close()
            queue_in.close()
            queue_out.close()
            try:
                time.sleep(0.5)
                [cons.close() for cons in consumer_list]
            except:
                time.sleep(1)
                [cons.close() for cons in consumer_list]

            dFrame = list_return[0]
            for lt in list_return[1:]:
                dFrame = dFrame.append(lt,ignore_index = True)
            dFrame = dFrame.sort_values(by=0)
            dFrame = dFrame.groupby(by = 0).sum()/dFrame.groupby(by=0).count()
            self.v0,self.d0 = np.asarray(list(dFrame[1]),np.float), np.asarray(dFrame[2],np.float)[:,None]
            self.p0,self.T0 = np.asarray(dFrame[3],np.float)[:,None], np.asarray(dFrame[4],np.float)[:,None]

            
           
#Creat a instance
if __name__ == '__main__':
    start = time.time()
    cbs = CBS()
    cbs.ParallelProcessing()

    #print(cbs.map_Inlet[1])
    #print(cbs.minLen)
    #print(cbs.maxLen)
    stop = time.time() - start
    print('Tempo percorrido:: %.3f'%stop)  

