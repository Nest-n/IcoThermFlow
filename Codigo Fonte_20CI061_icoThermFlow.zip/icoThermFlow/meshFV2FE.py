import numpy as np
import multiprocessing as mtp
import modin.pandas as mdp
import pandas as pd
import os,time
class mesh_BlockMesh():
    def __init__(self):
        '''========         SETUP PRE-PROCESSING       =========='''
        
        kwargs01 = dict(skiprows = 30,sep = '\s+', skipfooter = 0,  #|
                    low_memory = False)                             #|
        kwargs02 = dict(skiprows = 19,sep = '\s+', skipfooter = 1,  #|
                    low_memory = False)                             #|
                                                                    #|
        self.paths = ['./log.printPointCells',                      #|
                      './log.printPointFaces',                      #|
                      './log.printFacesCell',                       #|
                      './points']                                   #|
                                                                    #|
        self.kwargs = [kwargs01,kwargs01,kwargs01,kwargs02]         #|  
        #Patch Boundaty definite in BlockMesh                       #|
        self.patchBoundary = np.array((                             #|
                    'inlet','outlet','WallLower',                   #|
                    'WallUpper','WallLeft','WallRight'              #|
                                    ))                              #|
    def readAchive(self,args):
        path,kwarg = args
        'read BlockMesh archives for the DataFrame'
        return mdp.read_csv(path,**kwarg)

    def reader(cls):
        #Reading in process parallel
        df = []
        for i in range(len(cls.paths)):
            df.append(cls.readAchive((cls.paths[i],
                                      cls.kwargs[i]))) 
        #Converting DataFrame to numpy.array
        df0 = np.asarray(df[0],np.int)
        df1 = np.asarray(df[1],np.int)
        df2 = np.asarray(df[2],np.int)
        df3 = np.asarray(df[3],np.float)
        cls.ele,cls.nodesCell = df0[:,0],df0[:,1:]
        cls.IDfaces,cls.nodesFaces = df1[:,0],df1[:,1:]
        cls.facesCell,cls.coordPoints = df2[:,1:],df3
       
    def mapping(self):
        self.reader()
        structPatch = ['type','nFaces','startFace']
        featurePatch = np.zeros(( len(self.patchBoundary),
                                  len(structPatch)),'U30'
                                )
        with open('./constant/polyMesh/boundary') as fileBoundary:
            lineBoundary = fileBoundary.readlines()
            lineBoundary = [line.strip() for line in lineBoundary]
            lineBoundary = lineBoundary[17:] #Skiprows 
            textBoundary = (' ').join(lineBoundary)
            
            for line in lineBoundary:
                for n,patch in enumerate(self.patchBoundary):
                    if patch in line:
                        txSt = textBoundary[textBoundary.index(patch)
                                    + len(patch) + 3:]
                        txSt = txSt[:txSt.index('}')].split(';')
                        for st,struct in enumerate(structPatch):
                            for iSt in txSt:
                                if struct in iSt:
                                    #Matriz of string -> structPatch
                                    _,featurePatch[n,st] = iSt.split()
            featurePatch = np.hstack((
                    self.patchBoundary[:,None],featurePatch
                                    ))
        '/--------------------------------------------------------\ '
        '>>>>>                 MAPPING BOUNDARY              <<<<<'
        '\--------------------------------------------------------/ '
        def EleBoundary(name):
            mask = featurePatch[featurePatch[:,0] == name]
            nfaces = np.int(mask[:,2])
            start = np.int(mask[:,-1])
            #Points and Elements in boundary patchs
            idPtFaces = np.unique(
                    self.nodesFaces[start:start + nfaces])
            idFacesCell = self.IDfaces[
                            start:start + nfaces]
            eleB,_ = np.argwhere(np.isin(
                            self.facesCell,idFacesCell)).T
            return (eleB,idPtFaces)
        try:
            for name in self.patchBoundary:
                np.savetxt('./constant/ElementsBoundary/ele_%s'%name,
                           EleBoundary(name)[0][:,None],fmt='%d')
                np.savetxt('./constant/NodesBoundary/nodes_%s'%name,
                           EleBoundary(name)[1][:,None],fmt='%d')
        except:
            os.mkdir('./constant/ElementsBoundary/')
            os.mkdir('./constant/NodesBoundary/')
            for name in self.patchBoundary:
                np.savetxt('./constant/ElementsBoundary/ele_%s'%name,
                           EleBoundary(name)[0][:,None],fmt='%d')
                np.savetxt('./constant/NodesBoundary/nodes_%s'%name,
                           EleBoundary(name)[1][:,None],fmt='%d')

class NewAssembly(mesh_BlockMesh):
    def __init__(self):
        mesh_BlockMesh.__init__(self)
        mesh_BlockMesh.mapping(self)
        self.queue_in = mtp.JoinableQueue()
        self.queue_out= mtp.Queue()
        self.nWorkers = mtp.cpu_count()

    def isoHex8(self):
        '''
            This function aims to return the gauss points
        to an 8-node Hexahedral Isoparametric mesh.

        Local coordenates of nodes in elements ---> (ξ,η,ζ)

        IOANNIS et al. Fundamentals of Finite Element Analysis. 2018.
                        pag 274.

                             7------------6
                            /|           /|
                           / |          / |
                          /  |         /  |
                         /   |        /   |
                        4----|-------5    |
                        |    3-------|----2
          ζ             |   /        |   /
          ^ η           |  /         |  /
          | /           | /          | /
          |/            |/           |/
          |------>ξ     0------------1
        '''
        ##lN -> Local nodes
        ##gaussP or gP -> Gauss Points
        ##wGauss -> weight Gauss Points
        self.lN = np.array((
                    (-1,-1,-1),
                    (1,-1,-1),
                    (1,1,-1),
                    (-1,1,-1),
                    (-1,-1,1),
                    (1,-1,1),
                    (1,1,1),
                    (-1,1,1)
                        ))
        self.gaussP = np.array((
                    (-1/3**0.5,-1/3**0.5,-1/3**0.5),
                    (1/3**0.5,-1/3**0.5,-1/3**0.5),
                    (1/3**0.5,1/3**0.5,-1/3**0.5),
                    (-1/3**0.5,1/3**0.5,-1/3**0.5),
                    (-1/3**0.5,-1/3**0.5,1/3**0.5),
                    (1/3**0.5,-1/3**0.5,1/3**0.5),
                    (1/3**0.5,1/3**0.5,1/3**0.5),
                    (-1/3**0.5,1/3**0.5,1/3**0.5)
                        ))
    def Hex8Mesh(self,nodes,gP):
        '''
            Application of interpolation functions. These
        take into account only the mesh element geometry,
        as my mesh is initially composed of HEXAHEDRONS
        ISOPARAMETRIC elements,

        IOANNIS et al. Fundamentals of Finite Element Analysis. 2018.
        pag 266.
        '''
        csi,eta,zeta = gP.T
        #Interpolation Functions
        self.N = 1/8*np.array((
            (1-csi)*(1-eta)*(1-zeta),(1+csi)*(1-eta)*(1-zeta),
            (1+csi)*(1+eta)*(1-zeta),(1-csi)*(1+eta)*(1-zeta),
            (1-csi)*(1-eta)*(1+zeta),(1+csi)*(1-eta)*(1+zeta),
            (1+csi)*(1+eta)*(1+zeta),(1-csi)*(1+eta)*(1+zeta)
                        ))
        #Derivatives of Interpolation Funstions
        'IOANNIS (2018) pag 269'
        self.dNdcsi = 1/8*np.array((
            (-(1-eta)*(1-zeta), (1-eta)*(1-zeta),
              (1+eta)*(1-zeta),-(1+eta)*(1-zeta),
             -(1-eta)*(1+zeta), (1-eta)*(1+zeta),
              (1+eta)*(1+zeta),-(1+eta)*(1+zeta)),
            (-(1-csi)*(1-zeta),-(1+csi)*(1-zeta),
              (1+csi)*(1-zeta), (1-csi)*(1-zeta),
             -(1-csi)*(1+zeta),-(1+csi)*(1+zeta),
              (1+csi)*(1+zeta), (1-csi)*(1+zeta)),
            (-(1-csi)*(1-eta),-(1+csi)*(1-eta),
             -(1+csi)*(1+eta),-(1-csi)*(1+eta),
              (1-csi)*(1-eta), (1+csi)*(1-eta),
              (1+csi)*(1+eta), (1-csi)*(1+eta))
                                  ))
        J = (self.coordPoints[nodes].T@self.dNdcsi.T).T #Jacobian
        self.detJ = np.linalg.det(J)  #Det of Jacobian
    
    def verify(self,l_Ele,nodes):
        self.isoHex8()
        for el,_ in enumerate(l_Ele):
            for pos,ln in enumerate(self.lN):
                self.Hex8Mesh(nodes[el],ln)
                if self.detJ < 0:
                    for i in range(pos,
                        len(nodes[el])-1):
                        aux = nodes[el,pos].copy()
                        nodes[el,pos] = (
                        nodes[el,i + 1].copy())
                        nodes[el,i + 1] = aux
                        self.Hex8Mesh(nodes[el],ln)
                        if self.detJ > 0:
                            break
                self.Hex8Mesh(nodes[el],ln)
                if self.detJ < 0:
                    print('ERROR --> Jacobian >> Element: ',el)
            self.Hex8Mesh(nodes[el],self.gaussP[0])
            if self.detJ < 0:
                print('ERROR 2222 --> Jacobian >> Element: ',el)
            caracLen = np.max(np.sqrt(np.sum((
                self.coordPoints[nodes[el][0]] - 
                self.coordPoints[nodes[el][1:]])**2,axis=1)))
        return nodes

    def producer(self,EleT,queue_in):
        try:
            split_Ele = np.hsplit(EleT,self.nWorkers)
            for s in split_Ele:
                queue_in.put(s)
        except:
            split_Ele = np.hsplit(EleT,10)
            for s in split_Ele:
                queue_in.put(s)

    def consumer(self,queue_in,queue_out): 
        while True:
            EleT = queue_in.get()
            newNodes = self.verify(EleT,self.nodesCell[EleT])
            for i,el in enumerate(EleT):
                queue_out.put((el,newNodes[i]))
            queue_in.task_done()

    def ParallelCheckMesh(self):
        consumer_list = []
        for i in range(self.nWorkers):
            cons = mtp.Process(target = self.consumer,
                        args = (self.queue_in,self.queue_out))
            consumer_list.append(cons)
        [cons.start() for cons in consumer_list]
        prod = mtp.Process(target = self.producer,
                        args = (self.ele,self.queue_in))
        prod.start()
        prod.join()
        self.queue_in.join()
        retEle,newNodes = [],[]
        while not self.queue_out.empty():
            auxEle,auxNodes = self.queue_out.get()
            retEle.append(auxEle)
            newNodes.append(auxNodes)
        
        [cons.terminate() for cons in consumer_list]
        time.sleep(0.1)
        [cons.close() for cons in consumer_list]
        prod.close()
        self.nodesCell[retEle] = newNodes
        np.savetxt('./log.Assembly',self.nodesCell,fmt = '%d')
#Creat a instance
if __name__ == '__main__':
    cbs = NewAssembly()
    cbs.ParallelCheckMesh()
